import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import Icon from '../AppIcon';

const Breadcrumb = ({ customItems = null }) => {
  const location = useLocation();
  
  const generateBreadcrumbs = () => {
    if (customItems) {
      return customItems;
    }

    const pathSegments = location?.pathname?.split('/')?.filter(Boolean);
    const breadcrumbs = [{ label: 'Dashboard', path: '/dashboard', icon: 'Home' }];

    if (pathSegments?.length === 0 || location?.pathname === '/dashboard') {
      return breadcrumbs;
    }

    // Customer-related paths
    if (pathSegments?.includes('customer-list')) {
      breadcrumbs?.push({ label: 'Customers', path: '/customer-list', icon: 'Users' });
    } else if (pathSegments?.includes('customer-details')) {
      breadcrumbs?.push({ label: 'Customers', path: '/customer-list', icon: 'Users' });
      breadcrumbs?.push({ label: 'Customer Details', path: location?.pathname, icon: 'User' });
    } else if (pathSegments?.includes('add-edit-customer')) {
      breadcrumbs?.push({ label: 'Customers', path: '/customer-list', icon: 'Users' });
      const isEdit = location?.search?.includes('edit') || pathSegments?.length > 1;
      breadcrumbs?.push({ 
        label: isEdit ? 'Edit Customer' : 'Add Customer', 
        path: location?.pathname, 
        icon: isEdit ? 'Edit' : 'Plus' 
      });
    }
    // Lead-related paths
    else if (pathSegments?.includes('lead-management')) {
      breadcrumbs?.push({ label: 'Leads', path: '/lead-management', icon: 'Target' });
    } else if (pathSegments?.includes('add-edit-lead')) {
      breadcrumbs?.push({ label: 'Leads', path: '/lead-management', icon: 'Target' });
      const isEdit = location?.search?.includes('edit') || pathSegments?.length > 1;
      breadcrumbs?.push({ 
        label: isEdit ? 'Edit Lead' : 'Add Lead', 
        path: location?.pathname, 
        icon: isEdit ? 'Edit' : 'Plus' 
      });
    }

    return breadcrumbs;
  };

  const breadcrumbs = generateBreadcrumbs();

  if (breadcrumbs?.length <= 1) {
    return null;
  }

  return (
    <nav className="flex items-center space-x-2 text-sm text-muted-foreground mb-6" aria-label="Breadcrumb">
      <ol className="flex items-center space-x-2">
        {breadcrumbs?.map((item, index) => (
          <li key={item?.path} className="flex items-center">
            {index > 0 && (
              <Icon name="ChevronRight" size={16} className="mx-2 text-muted-foreground/60" />
            )}
            {index === breadcrumbs?.length - 1 ? (
              <span className="flex items-center space-x-1 text-foreground font-medium">
                <Icon name={item?.icon} size={16} />
                <span>{item?.label}</span>
              </span>
            ) : (
              <Link
                to={item?.path}
                className="flex items-center space-x-1 hover:text-foreground transition-colors duration-150"
              >
                <Icon name={item?.icon} size={16} />
                <span>{item?.label}</span>
              </Link>
            )}
          </li>
        ))}
      </ol>
    </nav>
  );
};

export default Breadcrumb;