import React from 'react';
import Header from '../../components/ui/Header';
import Breadcrumb from '../../components/ui/Breadcrumb';
import PageHeader from './components/PageHeader';
import CustomerForm from './components/CustomerForm';

const AddEditCustomer = () => {
  // Mock current user for header
  const currentUser = {
    id: 1,
    name: 'John Doe',
    email: 'john.doe@minicrm.com'
  };

  const handleLogout = () => {
    // Handle logout logic
    console.log('User logged out');
  };

  return (
    <div className="min-h-screen bg-background">
      <Header currentUser={currentUser} onLogout={handleLogout} />
      
      <main className="pt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <Breadcrumb />
          <PageHeader />
          <CustomerForm />
        </div>
      </main>
    </div>
  );
};

export default AddEditCustomer;