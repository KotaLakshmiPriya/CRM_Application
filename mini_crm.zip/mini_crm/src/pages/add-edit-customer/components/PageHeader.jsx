import React from 'react';
import { useSearchParams } from 'react-router-dom';
import Icon from '../../../components/AppIcon';

const PageHeader = () => {
  const [searchParams] = useSearchParams();
  const customerId = searchParams?.get('id');
  const isEditMode = !!customerId;

  return (
    <div className="mb-8">
      <div className="flex items-center space-x-3 mb-2">
        <div className="flex items-center justify-center w-10 h-10 bg-primary/10 rounded-lg">
          <Icon name={isEditMode ? "Edit" : "UserPlus"} size={24} color="var(--color-primary)" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-foreground">
            {isEditMode ? 'Edit Customer' : 'Add New Customer'}
          </h1>
          <p className="text-muted-foreground">
            {isEditMode 
              ? 'Update customer information and contact details' 
              : 'Create a new customer profile with contact information'
            }
          </p>
        </div>
      </div>
    </div>
  );
};

export default PageHeader;