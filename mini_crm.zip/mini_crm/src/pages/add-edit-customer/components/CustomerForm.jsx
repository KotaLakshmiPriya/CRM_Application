import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import Input from '../../../components/ui/Input';
import Button from '../../../components/ui/Button';
import Icon from '../../../components/AppIcon';

const CustomerForm = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const customerId = searchParams?.get('id');
  const isEditMode = !!customerId;

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    company: '',
    address: '',
    city: '',
    state: '',
    zipCode: '',
    country: 'United States'
  });

  const [errors, setErrors] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Mock customer data for edit mode
  const mockCustomers = [
    {
      id: '1',
      name: 'John Smith',
      email: 'john.smith@techcorp.com',
      phone: '+1 (555) 123-4567',
      company: 'TechCorp Solutions',
      address: '123 Business Ave',
      city: 'San Francisco',
      state: 'CA',
      zipCode: '94105',
      country: 'United States'
    },
    {
      id: '2',
      name: 'Sarah Johnson',
      email: 'sarah.johnson@innovate.com',
      phone: '+1 (555) 987-6543',
      company: 'Innovate Inc',
      address: '456 Innovation Blvd',
      city: 'Austin',
      state: 'TX',
      zipCode: '73301',
      country: 'United States'
    }
  ];

  useEffect(() => {
    if (isEditMode && customerId) {
      setIsLoading(true);
      // Simulate API call to fetch customer data
      setTimeout(() => {
        const customer = mockCustomers?.find(c => c?.id === customerId);
        if (customer) {
          setFormData({
            name: customer?.name,
            email: customer?.email,
            phone: customer?.phone,
            company: customer?.company,
            address: customer?.address,
            city: customer?.city,
            state: customer?.state,
            zipCode: customer?.zipCode,
            country: customer?.country
          });
        }
        setIsLoading(false);
      }, 800);
    }
  }, [customerId, isEditMode]);

  const validateForm = () => {
    const newErrors = {};

    // Name validation
    if (!formData?.name?.trim()) {
      newErrors.name = 'Customer name is required';
    } else if (formData?.name?.trim()?.length < 2) {
      newErrors.name = 'Name must be at least 2 characters long';
    }

    // Email validation
    if (!formData?.email?.trim()) {
      newErrors.email = 'Email address is required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/?.test(formData?.email)) {
      newErrors.email = 'Please enter a valid email address';
    }

    // Phone validation
    if (!formData?.phone?.trim()) {
      newErrors.phone = 'Phone number is required';
    } else if (!/^\+?[\d\s\-\(\)]{10,}$/?.test(formData?.phone?.replace(/\s/g, ''))) {
      newErrors.phone = 'Please enter a valid phone number';
    }

    // Company validation
    if (!formData?.company?.trim()) {
      newErrors.company = 'Company name is required';
    }

    // Address validation
    if (!formData?.address?.trim()) {
      newErrors.address = 'Address is required';
    }

    // City validation
    if (!formData?.city?.trim()) {
      newErrors.city = 'City is required';
    }

    // State validation
    if (!formData?.state?.trim()) {
      newErrors.state = 'State is required';
    }

    // Zip code validation
    if (!formData?.zipCode?.trim()) {
      newErrors.zipCode = 'ZIP code is required';
    } else if (!/^\d{5}(-\d{4})?$/?.test(formData?.zipCode)) {
      newErrors.zipCode = 'Please enter a valid ZIP code (e.g., 12345 or 12345-6789)';
    }

    setErrors(newErrors);
    return Object.keys(newErrors)?.length === 0;
  };

  const handleInputChange = (e) => {
    const { name, value } = e?.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));

    // Clear error for this field when user starts typing
    if (errors?.[name]) {
      setErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }
  };

  const handleSubmit = async (e) => {
    e?.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    setIsSubmitting(true);

    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Success - redirect to customer list
      navigate('/customer-list', { 
        state: { 
          message: `Customer ${isEditMode ? 'updated' : 'created'} successfully!`,
          type: 'success'
        }
      });
    } catch (error) {
      setErrors({
        submit: `Failed to ${isEditMode ? 'update' : 'create'} customer. Please try again.`
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCancel = () => {
    navigate('/customer-list');
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="flex items-center space-x-3">
          <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary"></div>
          <span className="text-muted-foreground">Loading customer data...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto">
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Basic Information Section */}
        <div className="bg-card rounded-lg border border-border p-6">
          <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center">
            <Icon name="User" size={20} className="mr-2" />
            Basic Information
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Input
              label="Customer Name"
              type="text"
              name="name"
              value={formData?.name}
              onChange={handleInputChange}
              placeholder="Enter customer name"
              error={errors?.name}
              required
            />

            <Input
              label="Email Address"
              type="email"
              name="email"
              value={formData?.email}
              onChange={handleInputChange}
              placeholder="customer@company.com"
              error={errors?.email}
              required
            />

            <Input
              label="Phone Number"
              type="tel"
              name="phone"
              value={formData?.phone}
              onChange={handleInputChange}
              placeholder="+1 (555) 123-4567"
              error={errors?.phone}
              required
            />

            <Input
              label="Company Name"
              type="text"
              name="company"
              value={formData?.company}
              onChange={handleInputChange}
              placeholder="Enter company name"
              error={errors?.company}
              required
            />
          </div>
        </div>

        {/* Address Information Section */}
        <div className="bg-card rounded-lg border border-border p-6">
          <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center">
            <Icon name="MapPin" size={20} className="mr-2" />
            Address Information
          </h3>
          
          <div className="grid grid-cols-1 gap-6">
            <Input
              label="Street Address"
              type="text"
              name="address"
              value={formData?.address}
              onChange={handleInputChange}
              placeholder="Enter street address"
              error={errors?.address}
              required
            />

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Input
                label="City"
                type="text"
                name="city"
                value={formData?.city}
                onChange={handleInputChange}
                placeholder="Enter city"
                error={errors?.city}
                required
              />

              <Input
                label="State"
                type="text"
                name="state"
                value={formData?.state}
                onChange={handleInputChange}
                placeholder="Enter state"
                error={errors?.state}
                required
              />

              <Input
                label="ZIP Code"
                type="text"
                name="zipCode"
                value={formData?.zipCode}
                onChange={handleInputChange}
                placeholder="12345"
                error={errors?.zipCode}
                required
              />
            </div>

            <Input
              label="Country"
              type="text"
              name="country"
              value={formData?.country}
              onChange={handleInputChange}
              placeholder="Enter country"
              disabled
            />
          </div>
        </div>

        {/* Submit Error */}
        {errors?.submit && (
          <div className="bg-error/10 border border-error/20 rounded-lg p-4">
            <div className="flex items-center space-x-2">
              <Icon name="AlertCircle" size={20} color="var(--color-error)" />
              <span className="text-error text-sm font-medium">{errors?.submit}</span>
            </div>
          </div>
        )}

        {/* Form Actions */}
        <div className="flex items-center justify-end space-x-4 pt-6 border-t border-border">
          <Button
            type="button"
            variant="outline"
            onClick={handleCancel}
            disabled={isSubmitting}
          >
            Cancel
          </Button>
          
          <Button
            type="submit"
            loading={isSubmitting}
            iconName="Save"
            iconPosition="left"
          >
            {isEditMode ? 'Update Customer' : 'Save Customer'}
          </Button>
        </div>
      </form>
    </div>
  );
};

export default CustomerForm;