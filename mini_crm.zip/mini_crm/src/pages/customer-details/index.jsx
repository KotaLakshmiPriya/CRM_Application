import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import Header from '../../components/ui/Header';
import Breadcrumb from '../../components/ui/Breadcrumb';
import CustomerInfoCard from './components/CustomerInfoCard';
import LeadsTable from './components/LeadsTable';
import DeleteConfirmationModal from './components/DeleteConfirmationModal';

const CustomerDetails = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const customerId = searchParams?.get('id');

  const [customer, setCustomer] = useState(null);
  const [leads, setLeads] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  // Mock current user
  const currentUser = {
    id: 1,
    name: "John Smith",
    email: "john.smith@company.com"
  };

  // Mock customer data
  const mockCustomers = [
    {
      id: 1,
      name: "Sarah Johnson",
      email: "sarah.johnson@techcorp.com",
      phone: "+1 (555) 123-4567",
      company: "TechCorp Solutions",
      position: "Chief Technology Officer",
      industry: "Technology",
      createdAt: "March 15, 2024",
      notes: `Sarah is a key decision-maker at TechCorp Solutions, focusing on digital transformation initiatives. She has expressed strong interest in our enterprise software solutions and is currently evaluating options for their Q2 2024 technology upgrade.

Key discussion points from our last meeting:
- Budget allocation of $150K-$200K for new software solutions
- Timeline for implementation: Q2 2024
- Primary concerns: data security and integration capabilities
- Decision-making process involves 3-person committee`
    },
    {
      id: 2,
      name: "Michael Rodriguez",
      email: "m.rodriguez@innovateplus.com",
      phone: "+1 (555) 987-6543",
      company: "InnovatePlus Inc",
      position: "VP of Operations",
      industry: "Manufacturing",
      createdAt: "February 8, 2024",
      notes: "Michael oversees operational efficiency initiatives and is interested in automation solutions."
    },
    {
      id: 3,
      name: "Emily Chen",
      email: "emily.chen@globalventures.com",
      phone: "+1 (555) 456-7890",
      company: "Global Ventures LLC",
      position: "Marketing Director",
      industry: "Consulting",
      createdAt: "January 22, 2024",
      notes: "Emily is looking for marketing automation tools to streamline their client acquisition process."
    }
  ];

  // Mock leads data
  const mockLeads = [
    {
      id: 1,
      customerId: 1,
      title: "Enterprise Software License",
      description: "Annual license for enterprise-grade project management software with advanced analytics and reporting capabilities.",
      status: "Contacted",
      value: 85000,
      createdAt: "2024-09-05T10:30:00Z"
    },
    {
      id: 2,
      customerId: 1,
      title: "Cloud Infrastructure Migration",
      description: "Complete migration of existing infrastructure to cloud-based solutions with 24/7 support and monitoring.",
      status: "New",
      value: 120000,
      createdAt: "2024-09-08T14:15:00Z"
    },
    {
      id: 3,
      customerId: 1,
      title: "Security Audit & Compliance",
      description: "Comprehensive security assessment and compliance certification for SOC 2 Type II requirements.",
      status: "Converted",
      value: 45000,
      createdAt: "2024-08-28T09:45:00Z"
    },
    {
      id: 4,
      customerId: 2,
      title: "Manufacturing Automation System",
      description: "Implementation of automated quality control systems for production line optimization.",
      status: "Lost",
      value: 200000,
      createdAt: "2024-08-15T11:20:00Z"
    },
    {
      id: 5,
      customerId: 3,
      title: "Marketing Analytics Platform",
      description: "Advanced marketing analytics and customer journey tracking platform with AI-powered insights.",
      status: "New",
      value: 35000,
      createdAt: "2024-09-02T16:30:00Z"
    }
  ];

  useEffect(() => {
    const fetchCustomerData = async () => {
      setLoading(true);
      setError(null);

      try {
        // Simulate API delay
        await new Promise(resolve => setTimeout(resolve, 800));

        const foundCustomer = mockCustomers?.find(c => c?.id === parseInt(customerId));
        if (!foundCustomer) {
          setError('Customer not found');
          return;
        }

        const customerLeads = mockLeads?.filter(lead => lead?.customerId === parseInt(customerId));

        setCustomer(foundCustomer);
        setLeads(customerLeads);
      } catch (err) {
        setError('Failed to load customer data');
      } finally {
        setLoading(false);
      }
    };

    if (customerId) {
      fetchCustomerData();
    } else {
      setError('No customer ID provided');
      setLoading(false);
    }
  }, [customerId]);

  const handleEditCustomer = () => {
    navigate(`/add-edit-customer?edit=true&id=${customerId}`);
  };

  const handleDeleteCustomer = () => {
    setShowDeleteModal(true);
  };

  const handleConfirmDelete = async () => {
    setIsDeleting(true);
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Navigate back to customer list after successful deletion
      navigate('/customer-list');
    } catch (err) {
      setError('Failed to delete customer');
    } finally {
      setIsDeleting(false);
      setShowDeleteModal(false);
    }
  };

  const handleAddLead = () => {
    navigate(`/add-edit-lead?customerId=${customerId}`);
  };

  const handleDeleteLead = async (leadId) => {
    if (window.confirm('Are you sure you want to delete this lead?')) {
      try {
        // Simulate API call
        await new Promise(resolve => setTimeout(resolve, 500));
        
        // Remove lead from state
        setLeads(prevLeads => prevLeads?.filter(lead => lead?.id !== leadId));
      } catch (err) {
        setError('Failed to delete lead');
      }
    }
  };

  const handleLogout = () => {
    navigate('/');
  };

  const breadcrumbItems = [
    { label: 'Dashboard', path: '/dashboard', icon: 'Home' },
    { label: 'Customers', path: '/customer-list', icon: 'Users' },
    { label: customer ? customer?.name : 'Customer Details', path: `/customer-details?id=${customerId}`, icon: 'User' }
  ];

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Header currentUser={currentUser} onLogout={handleLogout} />
        <main className="pt-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <div className="flex items-center justify-center min-h-[400px]">
              <div className="text-center">
                <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
                <p className="text-muted-foreground">Loading customer details...</p>
              </div>
            </div>
          </div>
        </main>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-background">
        <Header currentUser={currentUser} onLogout={handleLogout} />
        <main className="pt-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <div className="flex items-center justify-center min-h-[400px]">
              <div className="text-center">
                <div className="w-16 h-16 bg-destructive/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl">⚠️</span>
                </div>
                <h3 className="text-lg font-medium text-foreground mb-2">Error Loading Customer</h3>
                <p className="text-muted-foreground mb-6">{error}</p>
                <button
                  onClick={() => navigate('/customer-list')}
                  className="px-4 py-2 bg-primary text-primary-foreground rounded-md hover:bg-primary/90 transition-colors"
                >
                  Back to Customer List
                </button>
              </div>
            </div>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header currentUser={currentUser} onLogout={handleLogout} />
      
      <main className="pt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <Breadcrumb customItems={breadcrumbItems} />
          
          <div className="space-y-8">
            <CustomerInfoCard
              customer={customer}
              onEdit={handleEditCustomer}
              onDelete={handleDeleteCustomer}
            />
            
            <LeadsTable
              leads={leads}
              onAddLead={handleAddLead}
              onDeleteLead={handleDeleteLead}
            />
          </div>
        </div>
      </main>

      <DeleteConfirmationModal
        isOpen={showDeleteModal}
        onClose={() => setShowDeleteModal(false)}
        onConfirm={handleConfirmDelete}
        customerName={customer?.name}
        isDeleting={isDeleting}
      />
    </div>
  );
};

export default CustomerDetails;