import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import LeadStatusBadge from './LeadStatusBadge';

const LeadsTable = ({ leads, onAddLead, onDeleteLead }) => {
  const [statusFilter, setStatusFilter] = useState('all');
  const [sortBy, setSortBy] = useState('createdAt');
  const [sortOrder, setSortOrder] = useState('desc');

  const statusOptions = [
    { value: 'all', label: 'All Leads' },
    { value: 'new', label: 'New' },
    { value: 'contacted', label: 'Contacted' },
    { value: 'converted', label: 'Converted' },
    { value: 'lost', label: 'Lost' }
  ];

  const filteredLeads = leads?.filter(lead => 
    statusFilter === 'all' || lead?.status?.toLowerCase() === statusFilter
  );

  const sortedLeads = [...filteredLeads]?.sort((a, b) => {
    let aValue = a?.[sortBy];
    let bValue = b?.[sortBy];

    if (sortBy === 'value') {
      aValue = parseFloat(aValue);
      bValue = parseFloat(bValue);
    } else if (sortBy === 'createdAt') {
      aValue = new Date(aValue);
      bValue = new Date(bValue);
    }

    if (sortOrder === 'asc') {
      return aValue > bValue ? 1 : -1;
    } else {
      return aValue < bValue ? 1 : -1;
    }
  });

  const handleSort = (field) => {
    if (sortBy === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(field);
      setSortOrder('desc');
    }
  };

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    })?.format(value);
  };

  const formatDate = (dateString) => {
    return new Date(dateString)?.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  return (
    <div className="bg-card border border-border rounded-lg">
      <div className="p-6 border-b border-border">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h2 className="text-lg font-semibold text-foreground">Associated Leads</h2>
            <p className="text-sm text-muted-foreground mt-1">
              {filteredLeads?.length} of {leads?.length} leads
            </p>
          </div>
          <div className="flex items-center space-x-3">
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e?.target?.value)}
              className="px-3 py-2 border border-border rounded-md text-sm bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
            >
              {statusOptions?.map(option => (
                <option key={option?.value} value={option?.value}>
                  {option?.label}
                </option>
              ))}
            </select>
            <Button
              variant="default"
              size="sm"
              iconName="Plus"
              iconPosition="left"
              onClick={onAddLead}
            >
              Add Lead
            </Button>
          </div>
        </div>
      </div>
      {sortedLeads?.length === 0 ? (
        <div className="p-12 text-center">
          <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
            <Icon name="Target" size={32} color="var(--color-muted-foreground)" />
          </div>
          <h3 className="text-lg font-medium text-foreground mb-2">No leads found</h3>
          <p className="text-muted-foreground mb-6">
            {statusFilter === 'all' 
              ? "This customer doesn't have any leads yet." : `No leads with status"${statusFilter}" found.`}
          </p>
          <Button
            variant="default"
            iconName="Plus"
            iconPosition="left"
            onClick={onAddLead}
          >
            Create First Lead
          </Button>
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-muted/50">
              <tr>
                <th className="text-left px-6 py-3">
                  <button
                    onClick={() => handleSort('title')}
                    className="flex items-center space-x-1 text-sm font-medium text-foreground hover:text-primary transition-colors"
                  >
                    <span>Lead Title</span>
                    {sortBy === 'title' && (
                      <Icon name={sortOrder === 'asc' ? 'ChevronUp' : 'ChevronDown'} size={16} />
                    )}
                  </button>
                </th>
                <th className="text-left px-6 py-3">
                  <span className="text-sm font-medium text-foreground">Status</span>
                </th>
                <th className="text-left px-6 py-3">
                  <button
                    onClick={() => handleSort('value')}
                    className="flex items-center space-x-1 text-sm font-medium text-foreground hover:text-primary transition-colors"
                  >
                    <span>Value</span>
                    {sortBy === 'value' && (
                      <Icon name={sortOrder === 'asc' ? 'ChevronUp' : 'ChevronDown'} size={16} />
                    )}
                  </button>
                </th>
                <th className="text-left px-6 py-3">
                  <button
                    onClick={() => handleSort('createdAt')}
                    className="flex items-center space-x-1 text-sm font-medium text-foreground hover:text-primary transition-colors"
                  >
                    <span>Created</span>
                    {sortBy === 'createdAt' && (
                      <Icon name={sortOrder === 'asc' ? 'ChevronUp' : 'ChevronDown'} size={16} />
                    )}
                  </button>
                </th>
                <th className="text-right px-6 py-3">
                  <span className="text-sm font-medium text-foreground">Actions</span>
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {sortedLeads?.map((lead) => (
                <tr key={lead?.id} className="hover:bg-muted/30 transition-colors">
                  <td className="px-6 py-4">
                    <div>
                      <p className="font-medium text-foreground">{lead?.title}</p>
                      {lead?.description && (
                        <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
                          {lead?.description}
                        </p>
                      )}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <LeadStatusBadge status={lead?.status} />
                  </td>
                  <td className="px-6 py-4">
                    <span className="font-medium text-foreground">
                      {formatCurrency(lead?.value)}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-sm text-muted-foreground">
                      {formatDate(lead?.createdAt)}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center justify-end space-x-2">
                      <Link
                        to={`/add-edit-lead?edit=true&id=${lead?.id}&customerId=${lead?.customerId}`}
                        className="p-2 text-muted-foreground hover:text-primary hover:bg-primary/10 rounded-md transition-colors"
                      >
                        <Icon name="Edit" size={16} />
                      </Link>
                      <button
                        onClick={() => onDeleteLead(lead?.id)}
                        className="p-2 text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded-md transition-colors"
                      >
                        <Icon name="Trash2" size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default LeadsTable;