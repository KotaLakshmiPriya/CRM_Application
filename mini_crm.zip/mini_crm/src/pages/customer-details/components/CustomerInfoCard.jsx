import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const CustomerInfoCard = ({ customer, onEdit, onDelete }) => {
  return (
    <div className="bg-card border border-border rounded-lg p-6">
      <div className="flex items-start justify-between mb-6">
        <div className="flex items-center space-x-4">
          <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center">
            <Icon name="User" size={32} color="var(--color-primary)" />
          </div>
          <div>
            <h1 className="text-2xl font-semibold text-foreground">{customer?.name}</h1>
            <p className="text-muted-foreground">{customer?.company}</p>
          </div>
        </div>
        <div className="flex items-center space-x-2">
          <Button
            variant="outline"
            size="sm"
            iconName="Edit"
            iconPosition="left"
            onClick={onEdit}
          >
            Edit
          </Button>
          <Button
            variant="destructive"
            size="sm"
            iconName="Trash2"
            iconPosition="left"
            onClick={onDelete}
          >
            Delete
          </Button>
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <div>
            <label className="text-sm font-medium text-muted-foreground">Email Address</label>
            <p className="text-foreground mt-1">{customer?.email}</p>
          </div>
          <div>
            <label className="text-sm font-medium text-muted-foreground">Phone Number</label>
            <p className="text-foreground mt-1">{customer?.phone}</p>
          </div>
          <div>
            <label className="text-sm font-medium text-muted-foreground">Company</label>
            <p className="text-foreground mt-1">{customer?.company}</p>
          </div>
        </div>

        <div className="space-y-4">
          <div>
            <label className="text-sm font-medium text-muted-foreground">Position</label>
            <p className="text-foreground mt-1">{customer?.position}</p>
          </div>
          <div>
            <label className="text-sm font-medium text-muted-foreground">Industry</label>
            <p className="text-foreground mt-1">{customer?.industry}</p>
          </div>
          <div>
            <label className="text-sm font-medium text-muted-foreground">Customer Since</label>
            <p className="text-foreground mt-1">{customer?.createdAt}</p>
          </div>
        </div>
      </div>
      {customer?.notes && (
        <div className="mt-6 pt-6 border-t border-border">
          <label className="text-sm font-medium text-muted-foreground">Notes</label>
          <p className="text-foreground mt-2 leading-relaxed">{customer?.notes}</p>
        </div>
      )}
    </div>
  );
};

export default CustomerInfoCard;