import React, { useState, useEffect, useMemo } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import Header from '../../components/ui/Header';
import Breadcrumb from '../../components/ui/Breadcrumb';
import Button from '../../components/ui/Button';
import CustomerTable from './components/CustomerTable';
import CustomerSearch from './components/CustomerSearch';
import CustomerPagination from './components/CustomerPagination';
import CustomerEmptyState from './components/CustomerEmptyState';
import CustomerBulkActions from './components/CustomerBulkActions';

const CustomerList = () => {
  const navigate = useNavigate();
  
  // Mock current user
  const currentUser = {
    id: 1,
    name: "John Smith",
    email: "john.smith@company.com"
  };

  // Mock customers data
  const mockCustomers = [
    {
      id: 1,
      name: "Sarah Johnson",
      email: "sarah.johnson@techcorp.com",
      phone: "+1 (555) 123-4567",
      company: "TechCorp Solutions",
      lastContact: "2025-01-08T10:30:00Z",
      createdAt: "2024-11-15T09:00:00Z"
    },
    {
      id: 2,
      name: "Michael Chen",
      email: "m.chen@innovatetech.com",
      phone: "+1 (555) 234-5678",
      company: "InnovateTech Inc",
      lastContact: "2025-01-07T14:15:00Z",
      createdAt: "2024-12-02T11:30:00Z"
    },
    {
      id: 3,
      name: "Emily Rodriguez",
      email: "emily.r@globalventures.com",
      phone: "+1 (555) 345-6789",
      company: "Global Ventures LLC",
      lastContact: "2025-01-06T16:45:00Z",
      createdAt: "2024-10-20T08:15:00Z"
    },
    {
      id: 4,
      name: "David Thompson",
      email: "david.thompson@startupx.com",
      phone: "+1 (555) 456-7890",
      company: "StartupX",
      lastContact: "2025-01-05T09:20:00Z",
      createdAt: "2024-12-10T13:45:00Z"
    },
    {
      id: 5,
      name: "Lisa Wang",
      email: "lisa.wang@futuretech.com",
      phone: "+1 (555) 567-8901",
      company: "FutureTech Systems",
      lastContact: "2025-01-04T11:10:00Z",
      createdAt: "2024-11-28T10:20:00Z"
    },
    {
      id: 6,
      name: "Robert Martinez",
      email: "r.martinez@digitalflow.com",
      phone: "+1 (555) 678-9012",
      company: "DigitalFlow Agency",
      lastContact: "2025-01-03T15:30:00Z",
      createdAt: "2024-12-05T14:00:00Z"
    },
    {
      id: 7,
      name: "Jennifer Lee",
      email: "jennifer.lee@cloudnine.com",
      phone: "+1 (555) 789-0123",
      company: "CloudNine Technologies",
      lastContact: "2025-01-02T12:45:00Z",
      createdAt: "2024-11-18T16:30:00Z"
    },
    {
      id: 8,
      name: "Alex Kumar",
      email: "alex.kumar@nexusgroup.com",
      phone: "+1 (555) 890-1234",
      company: "Nexus Group",
      lastContact: "2025-01-01T10:00:00Z",
      createdAt: "2024-12-15T09:45:00Z"
    },
    {
      id: 9,
      name: "Maria Garcia",
      email: "maria.garcia@brightfuture.com",
      phone: "+1 (555) 901-2345",
      company: "BrightFuture Consulting",
      lastContact: "2024-12-31T14:20:00Z",
      createdAt: "2024-10-30T11:15:00Z"
    },
    {
      id: 10,
      name: "James Wilson",
      email: "james.wilson@alphatech.com",
      phone: "+1 (555) 012-3456",
      company: "AlphaTech Solutions",
      lastContact: "2024-12-30T16:10:00Z",
      createdAt: "2024-11-25T13:20:00Z"
    },
    {
      id: 11,
      name: "Amanda Foster",
      email: "amanda.foster@innovateplus.com",
      phone: "+1 (555) 123-4567",
      company: "InnovatePlus",
      lastContact: "2024-12-29T09:30:00Z",
      createdAt: "2024-12-01T15:10:00Z"
    },
    {
      id: 12,
      name: "Kevin Park",
      email: "kevin.park@techbridge.com",
      phone: "+1 (555) 234-5678",
      company: "TechBridge Corp",
      lastContact: "2024-12-28T11:45:00Z",
      createdAt: "2024-11-08T12:30:00Z"
    }
  ];

  // State management
  const [customers, setCustomers] = useState(mockCustomers);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [sortField, setSortField] = useState('name');
  const [sortDirection, setSortDirection] = useState('asc');
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);
  const [selectedCustomers, setSelectedCustomers] = useState([]);

  // Filter customers based on search term
  const filteredCustomers = useMemo(() => {
    if (!searchTerm) return customers;
    
    return customers?.filter(customer =>
      customer?.name?.toLowerCase()?.includes(searchTerm?.toLowerCase()) ||
      customer?.email?.toLowerCase()?.includes(searchTerm?.toLowerCase())
    );
  }, [customers, searchTerm]);

  // Sort customers
  const sortedCustomers = useMemo(() => {
    return [...filteredCustomers]?.sort((a, b) => {
      let aValue = a?.[sortField];
      let bValue = b?.[sortField];
      
      if (sortField === 'lastContact') {
        aValue = new Date(aValue || 0);
        bValue = new Date(bValue || 0);
      } else if (typeof aValue === 'string') {
        aValue = aValue?.toLowerCase();
        bValue = bValue?.toLowerCase();
      }
      
      if (aValue < bValue) return sortDirection === 'asc' ? -1 : 1;
      if (aValue > bValue) return sortDirection === 'asc' ? 1 : -1;
      return 0;
    });
  }, [filteredCustomers, sortField, sortDirection]);

  // Paginate customers
  const paginatedCustomers = useMemo(() => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    return sortedCustomers?.slice(startIndex, startIndex + itemsPerPage);
  }, [sortedCustomers, currentPage, itemsPerPage]);

  const totalPages = Math.ceil(sortedCustomers?.length / itemsPerPage);

  // Handlers
  const handleSearchChange = (term) => {
    setSearchTerm(term);
    setCurrentPage(1);
    setSelectedCustomers([]);
  };

  const handleSort = (field) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const handlePageChange = (page) => {
    setCurrentPage(page);
    setSelectedCustomers([]);
  };

  const handleItemsPerPageChange = (newItemsPerPage) => {
    setItemsPerPage(newItemsPerPage);
    setCurrentPage(1);
    setSelectedCustomers([]);
  };

  const handleSelectCustomer = (customerId, isSelected) => {
    if (isSelected) {
      setSelectedCustomers([...selectedCustomers, customerId]);
    } else {
      setSelectedCustomers(selectedCustomers?.filter(id => id !== customerId));
    }
  };

  const handleSelectAll = (isSelected) => {
    if (isSelected) {
      setSelectedCustomers(paginatedCustomers?.map(customer => customer?.id));
    } else {
      setSelectedCustomers([]);
    }
  };

  const handleEdit = (customer) => {
    navigate(`/add-edit-customer?edit=true&id=${customer?.id}`);
  };

  const handleDelete = (customerId) => {
    setLoading(true);
    setTimeout(() => {
      setCustomers(customers?.filter(customer => customer?.id !== customerId));
      setSelectedCustomers(selectedCustomers?.filter(id => id !== customerId));
      setLoading(false);
    }, 500);
  };

  const handleBulkDelete = (customerIds) => {
    setLoading(true);
    setTimeout(() => {
      setCustomers(customers?.filter(customer => !customerIds?.includes(customer?.id)));
      setSelectedCustomers([]);
      setLoading(false);
    }, 500);
  };

  const handleBulkExport = (customerIds) => {
    const selectedCustomerData = customers?.filter(customer => customerIds?.includes(customer?.id));
    const csvContent = [
      ['Name', 'Email', 'Phone', 'Company', 'Last Contact'],
      ...selectedCustomerData?.map(customer => [
        customer?.name,
        customer?.email,
        customer?.phone || '',
        customer?.company || '',
        customer?.lastContact ? new Date(customer.lastContact)?.toLocaleDateString() : 'Never'
      ])
    ]?.map(row => row?.join(','))?.join('\n');
    
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL?.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `customers-export-${new Date()?.toISOString()?.split('T')?.[0]}.csv`;
    a?.click();
    window.URL?.revokeObjectURL(url);
  };

  const handleClearSelection = () => {
    setSelectedCustomers([]);
  };

  const handleLogout = () => {
    navigate('/');
  };

  // Reset page when search changes
  useEffect(() => {
    if (currentPage > totalPages && totalPages > 0) {
      setCurrentPage(1);
    }
  }, [currentPage, totalPages]);

  return (
    <div className="min-h-screen bg-background">
      <Header currentUser={currentUser} onLogout={handleLogout} />
      <main className="pt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <Breadcrumb />
          
          {/* Page Header */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-8">
            <div>
              <h1 className="text-3xl font-bold text-foreground mb-2">Customer Management</h1>
              <p className="text-muted-foreground">
                Manage your customer relationships and track interactions
              </p>
            </div>
            <div className="mt-4 sm:mt-0">
              <Link to="/add-edit-customer">
                <Button iconName="Plus" iconSize={16}>
                  Add Customer
                </Button>
              </Link>
            </div>
          </div>

          {/* Search */}
          <CustomerSearch
            searchTerm={searchTerm}
            onSearchChange={handleSearchChange}
            resultsCount={sortedCustomers?.length}
            totalCount={customers?.length}
          />

          {/* Bulk Actions */}
          <CustomerBulkActions
            selectedCustomers={selectedCustomers}
            onBulkDelete={handleBulkDelete}
            onBulkExport={handleBulkExport}
            onClearSelection={handleClearSelection}
          />

          {/* Customer Table or Empty State */}
          {sortedCustomers?.length === 0 ? (
            <CustomerEmptyState
              isSearching={!!searchTerm}
              searchTerm={searchTerm}
              onClearSearch={() => handleSearchChange('')}
            />
          ) : (
            <>
              <CustomerTable
                customers={paginatedCustomers}
                onEdit={handleEdit}
                onDelete={handleDelete}
                onSort={handleSort}
                sortField={sortField}
                sortDirection={sortDirection}
                selectedCustomers={selectedCustomers}
                onSelectCustomer={handleSelectCustomer}
                onSelectAll={handleSelectAll}
                loading={loading}
              />

              {/* Pagination */}
              <div className="mt-6">
                <CustomerPagination
                  currentPage={currentPage}
                  totalPages={totalPages}
                  totalItems={sortedCustomers?.length}
                  itemsPerPage={itemsPerPage}
                  onPageChange={handlePageChange}
                  onItemsPerPageChange={handleItemsPerPageChange}
                />
              </div>
            </>
          )}
        </div>
      </main>
    </div>
  );
};

export default CustomerList;