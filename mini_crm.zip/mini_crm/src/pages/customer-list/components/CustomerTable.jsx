import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const CustomerTable = ({ 
  customers, 
  onEdit, 
  onDelete, 
  onSort, 
  sortField, 
  sortDirection,
  selectedCustomers,
  onSelectCustomer,
  onSelectAll,
  loading 
}) => {
  const [deleteConfirm, setDeleteConfirm] = useState(null);

  const handleDeleteClick = (customer) => {
    setDeleteConfirm(customer);
  };

  const handleDeleteConfirm = () => {
    if (deleteConfirm) {
      onDelete(deleteConfirm?.id);
      setDeleteConfirm(null);
    }
  };

  const handleDeleteCancel = () => {
    setDeleteConfirm(null);
  };

  const formatDate = (dateString) => {
    if (!dateString) return 'Never';
    const date = new Date(dateString);
    return date?.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  const getSortIcon = (field) => {
    if (sortField !== field) return 'ArrowUpDown';
    return sortDirection === 'asc' ? 'ArrowUp' : 'ArrowDown';
  };

  const isAllSelected = customers?.length > 0 && selectedCustomers?.length === customers?.length;
  const isIndeterminate = selectedCustomers?.length > 0 && selectedCustomers?.length < customers?.length;

  if (loading) {
    return (
      <div className="bg-card rounded-lg border border-border overflow-hidden">
        <div className="p-8 text-center">
          <div className="inline-flex items-center justify-center w-12 h-12 bg-primary/10 rounded-lg mb-4">
            <Icon name="Loader2" size={24} color="var(--color-primary)" className="animate-spin" />
          </div>
          <p className="text-muted-foreground">Loading customers...</p>
        </div>
      </div>
    );
  }

  return (
    <>
      <div className="bg-card rounded-lg border border-border overflow-hidden">
        {/* Desktop Table */}
        <div className="hidden md:block overflow-x-auto">
          <table className="w-full">
            <thead className="bg-muted/50 border-b border-border">
              <tr>
                <th className="w-12 px-4 py-3">
                  <input
                    type="checkbox"
                    checked={isAllSelected}
                    ref={(el) => {
                      if (el) el.indeterminate = isIndeterminate;
                    }}
                    onChange={(e) => onSelectAll(e?.target?.checked)}
                    className="w-4 h-4 text-primary bg-background border-border rounded focus:ring-primary focus:ring-2"
                  />
                </th>
                <th className="text-left px-4 py-3">
                  <button
                    onClick={() => onSort('name')}
                    className="flex items-center space-x-2 text-sm font-medium text-foreground hover:text-primary transition-colors"
                  >
                    <span>Name</span>
                    <Icon name={getSortIcon('name')} size={16} />
                  </button>
                </th>
                <th className="text-left px-4 py-3">
                  <button
                    onClick={() => onSort('email')}
                    className="flex items-center space-x-2 text-sm font-medium text-foreground hover:text-primary transition-colors"
                  >
                    <span>Email</span>
                    <Icon name={getSortIcon('email')} size={16} />
                  </button>
                </th>
                <th className="text-left px-4 py-3">
                  <span className="text-sm font-medium text-foreground">Phone</span>
                </th>
                <th className="text-left px-4 py-3">
                  <span className="text-sm font-medium text-foreground">Company</span>
                </th>
                <th className="text-left px-4 py-3">
                  <button
                    onClick={() => onSort('lastContact')}
                    className="flex items-center space-x-2 text-sm font-medium text-foreground hover:text-primary transition-colors"
                  >
                    <span>Last Contact</span>
                    <Icon name={getSortIcon('lastContact')} size={16} />
                  </button>
                </th>
                <th className="text-right px-4 py-3">
                  <span className="text-sm font-medium text-foreground">Actions</span>
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {customers?.map((customer) => (
                <tr key={customer?.id} className="hover:bg-muted/30 transition-colors">
                  <td className="px-4 py-4">
                    <input
                      type="checkbox"
                      checked={selectedCustomers?.includes(customer?.id)}
                      onChange={(e) => onSelectCustomer(customer?.id, e?.target?.checked)}
                      className="w-4 h-4 text-primary bg-background border-border rounded focus:ring-primary focus:ring-2"
                    />
                  </td>
                  <td className="px-4 py-4">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                        <Icon name="User" size={20} color="var(--color-primary)" />
                      </div>
                      <div>
                        <Link
                          to={`/customer-details/${customer?.id}`}
                          className="font-medium text-foreground hover:text-primary transition-colors"
                        >
                          {customer?.name}
                        </Link>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-4">
                    <span className="text-sm text-muted-foreground">{customer?.email}</span>
                  </td>
                  <td className="px-4 py-4">
                    <span className="text-sm text-muted-foreground">{customer?.phone || 'N/A'}</span>
                  </td>
                  <td className="px-4 py-4">
                    <span className="text-sm text-muted-foreground">{customer?.company || 'N/A'}</span>
                  </td>
                  <td className="px-4 py-4">
                    <span className="text-sm text-muted-foreground">{formatDate(customer?.lastContact)}</span>
                  </td>
                  <td className="px-4 py-4">
                    <div className="flex items-center justify-end space-x-2">
                      <Link to={`/customer-details/${customer?.id}`}>
                        <Button variant="ghost" size="sm" iconName="Eye" iconSize={16}>
                          View
                        </Button>
                      </Link>
                      <Button
                        variant="ghost"
                        size="sm"
                        iconName="Edit"
                        iconSize={16}
                        onClick={() => onEdit(customer)}
                      >
                        Edit
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        iconName="Trash2"
                        iconSize={16}
                        onClick={() => handleDeleteClick(customer)}
                      >
                        Delete
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Mobile Cards */}
        <div className="md:hidden divide-y divide-border">
          {customers?.map((customer) => (
            <div key={customer?.id} className="p-4">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center space-x-3">
                  <input
                    type="checkbox"
                    checked={selectedCustomers?.includes(customer?.id)}
                    onChange={(e) => onSelectCustomer(customer?.id, e?.target?.checked)}
                    className="w-4 h-4 text-primary bg-background border-border rounded focus:ring-primary focus:ring-2 mt-1"
                  />
                  <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                    <Icon name="User" size={20} color="var(--color-primary)" />
                  </div>
                  <div>
                    <Link
                      to={`/customer-details/${customer?.id}`}
                      className="font-medium text-foreground hover:text-primary transition-colors"
                    >
                      {customer?.name}
                    </Link>
                    <p className="text-sm text-muted-foreground">{customer?.email}</p>
                  </div>
                </div>
              </div>
              
              <div className="space-y-2 mb-4">
                {customer?.phone && (
                  <div className="flex items-center space-x-2">
                    <Icon name="Phone" size={16} className="text-muted-foreground" />
                    <span className="text-sm text-muted-foreground">{customer?.phone}</span>
                  </div>
                )}
                {customer?.company && (
                  <div className="flex items-center space-x-2">
                    <Icon name="Building" size={16} className="text-muted-foreground" />
                    <span className="text-sm text-muted-foreground">{customer?.company}</span>
                  </div>
                )}
                <div className="flex items-center space-x-2">
                  <Icon name="Calendar" size={16} className="text-muted-foreground" />
                  <span className="text-sm text-muted-foreground">Last contact: {formatDate(customer?.lastContact)}</span>
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <Link to={`/customer-details/${customer?.id}`} className="flex-1">
                  <Button variant="outline" size="sm" fullWidth iconName="Eye" iconSize={16}>
                    View
                  </Button>
                </Link>
                <Button
                  variant="outline"
                  size="sm"
                  iconName="Edit"
                  iconSize={16}
                  onClick={() => onEdit(customer)}
                >
                  Edit
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  iconName="Trash2"
                  iconSize={16}
                  onClick={() => handleDeleteClick(customer)}
                >
                  Delete
                </Button>
              </div>
            </div>
          ))}
        </div>
      </div>
      {/* Delete Confirmation Modal */}
      {deleteConfirm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-card rounded-lg border border-border max-w-md w-full p-6">
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-10 h-10 bg-error/10 rounded-full flex items-center justify-center">
                <Icon name="AlertTriangle" size={20} color="var(--color-error)" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-foreground">Delete Customer</h3>
                <p className="text-sm text-muted-foreground">This action cannot be undone</p>
              </div>
            </div>
            
            <p className="text-sm text-muted-foreground mb-6">
              Are you sure you want to delete <strong>{deleteConfirm?.name}</strong>? This will also remove all associated leads and data.
            </p>
            
            <div className="flex items-center justify-end space-x-3">
              <Button variant="outline" onClick={handleDeleteCancel}>
                Cancel
              </Button>
              <Button variant="destructive" onClick={handleDeleteConfirm}>
                Delete Customer
              </Button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default CustomerTable;