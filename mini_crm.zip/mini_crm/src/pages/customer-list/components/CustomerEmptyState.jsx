import React from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const CustomerEmptyState = ({ isSearching, searchTerm, onClearSearch }) => {
  if (isSearching) {
    return (
      <div className="bg-card rounded-lg border border-border p-8 text-center">
        <div className="inline-flex items-center justify-center w-16 h-16 bg-muted rounded-full mb-4">
          <Icon name="Search" size={32} className="text-muted-foreground" />
        </div>
        <h3 className="text-lg font-semibold text-foreground mb-2">No customers found</h3>
        <p className="text-muted-foreground mb-6 max-w-md mx-auto">
          We couldn't find any customers matching "{searchTerm}". Try adjusting your search terms or browse all customers.
        </p>
        <div className="flex flex-col sm:flex-row items-center justify-center space-y-2 sm:space-y-0 sm:space-x-3">
          <Button variant="outline" onClick={onClearSearch} iconName="X" iconSize={16}>
            Clear Search
          </Button>
          <Link to="/add-edit-customer">
            <Button iconName="Plus" iconSize={16}>
              Add New Customer
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-card rounded-lg border border-border p-8 text-center">
      <div className="inline-flex items-center justify-center w-16 h-16 bg-primary/10 rounded-full mb-4">
        <Icon name="Users" size={32} color="var(--color-primary)" />
      </div>
      <h3 className="text-lg font-semibold text-foreground mb-2">No customers yet</h3>
      <p className="text-muted-foreground mb-6 max-w-md mx-auto">
        Get started by adding your first customer. You can track their information, manage leads, and build stronger relationships.
      </p>
      <Link to="/add-edit-customer">
        <Button iconName="Plus" iconSize={16}>
          Add Your First Customer
        </Button>
      </Link>
      
      <div className="mt-8 pt-6 border-t border-border">
        <h4 className="text-sm font-medium text-foreground mb-3">Quick Tips</h4>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-left">
          <div className="flex items-start space-x-3">
            <div className="w-8 h-8 bg-accent/10 rounded-lg flex items-center justify-center flex-shrink-0">
              <Icon name="UserPlus" size={16} color="var(--color-accent)" />
            </div>
            <div>
              <p className="text-sm font-medium text-foreground">Add Customers</p>
              <p className="text-xs text-muted-foreground">Store contact details and company information</p>
            </div>
          </div>
          <div className="flex items-start space-x-3">
            <div className="w-8 h-8 bg-warning/10 rounded-lg flex items-center justify-center flex-shrink-0">
              <Icon name="Target" size={16} color="var(--color-warning)" />
            </div>
            <div>
              <p className="text-sm font-medium text-foreground">Track Leads</p>
              <p className="text-xs text-muted-foreground">Manage opportunities and sales pipeline</p>
            </div>
          </div>
          <div className="flex items-start space-x-3">
            <div className="w-8 h-8 bg-success/10 rounded-lg flex items-center justify-center flex-shrink-0">
              <Icon name="TrendingUp" size={16} color="var(--color-success)" />
            </div>
            <div>
              <p className="text-sm font-medium text-foreground">Grow Business</p>
              <p className="text-xs text-muted-foreground">Convert leads and increase revenue</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CustomerEmptyState;