import React from 'react';
import Icon from '../../../components/AppIcon';
import Input from '../../../components/ui/Input';

const CustomerSearch = ({ searchTerm, onSearchChange, resultsCount, totalCount }) => {
  const handleClearSearch = () => {
    onSearchChange('');
  };

  return (
    <div className="bg-card rounded-lg border border-border p-4 mb-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-foreground">Search Customers</h3>
        {searchTerm && (
          <div className="text-sm text-muted-foreground">
            Showing {resultsCount} of {totalCount} customers
          </div>
        )}
      </div>
      <div className="relative">
        <div className="absolute left-3 top-1/2 transform -translate-y-1/2">
          <Icon name="Search" size={20} className="text-muted-foreground" />
        </div>
        
        <Input
          type="search"
          placeholder="Search by name or email..."
          value={searchTerm}
          onChange={(e) => onSearchChange(e?.target?.value)}
          className="pl-10 pr-10"
        />
        
        {searchTerm && (
          <button
            onClick={handleClearSearch}
            className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
          >
            <Icon name="X" size={20} />
          </button>
        )}
      </div>
      {searchTerm && (
        <div className="mt-3 flex items-center space-x-2">
          <div className="inline-flex items-center space-x-1 bg-primary/10 text-primary px-2 py-1 rounded-md text-sm">
            <Icon name="Filter" size={14} />
            <span>Active filter: "{searchTerm}"</span>
            <button
              onClick={handleClearSearch}
              className="ml-1 hover:bg-primary/20 rounded p-0.5 transition-colors"
            >
              <Icon name="X" size={12} />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default CustomerSearch;