import React from 'react';
import Select from '../../../components/ui/Select';
import Input from '../../../components/ui/Input';
import Button from '../../../components/ui/Button';


const LeadFilters = ({ 
  statusFilter, 
  setStatusFilter, 
  searchTerm, 
  setSearchTerm, 
  minValue, 
  setMinValue, 
  maxValue, 
  setMaxValue, 
  onClearFilters 
}) => {
  const statusOptions = [
    { value: 'all', label: 'All Statuses' },
    { value: 'New', label: 'New' },
    { value: 'Contacted', label: 'Contacted' },
    { value: 'Converted', label: 'Converted' },
    { value: 'Lost', label: 'Lost' }
  ];

  return (
    <div className="bg-white rounded-lg border border-gray-200 p-4 mb-6">
      <div className="flex flex-col lg:flex-row gap-4">
        {/* Search Input */}
        <div className="flex-1">
          <Input
            type="search"
            placeholder="Search by customer name or lead title..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e?.target?.value)}
            className="w-full"
          />
        </div>

        {/* Status Filter */}
        <div className="w-full lg:w-48">
          <Select
            options={statusOptions}
            value={statusFilter}
            onChange={setStatusFilter}
            placeholder="Filter by status"
          />
        </div>

        {/* Value Range Filters */}
        <div className="flex gap-2 w-full lg:w-auto">
          <Input
            type="number"
            placeholder="Min value"
            value={minValue}
            onChange={(e) => setMinValue(e?.target?.value)}
            className="w-32"
          />
          <Input
            type="number"
            placeholder="Max value"
            value={maxValue}
            onChange={(e) => setMaxValue(e?.target?.value)}
            className="w-32"
          />
        </div>

        {/* Clear Filters Button */}
        <Button
          variant="outline"
          onClick={onClearFilters}
          iconName="X"
          iconPosition="left"
          className="w-full lg:w-auto"
        >
          Clear
        </Button>
      </div>
    </div>
  );
};

export default LeadFilters;