import React from 'react';
import Icon from '../../../components/AppIcon';

const LeadSummaryCards = ({ leads }) => {
  const totalLeads = leads?.length;
  const newLeads = leads?.filter(lead => lead?.status === 'New')?.length;
  const convertedLeads = leads?.filter(lead => lead?.status === 'Converted')?.length;
  const totalValue = leads?.reduce((sum, lead) => sum + lead?.value, 0);
  const conversionRate = totalLeads > 0 ? ((convertedLeads / totalLeads) * 100)?.toFixed(1) : 0;

  const summaryData = [
    {
      title: 'Total Leads',
      value: totalLeads?.toLocaleString(),
      icon: 'Target',
      bgColor: 'bg-blue-50',
      iconColor: 'text-blue-600',
      textColor: 'text-blue-900'
    },
    {
      title: 'New Leads',
      value: newLeads?.toLocaleString(),
      icon: 'Plus',
      bgColor: 'bg-green-50',
      iconColor: 'text-green-600',
      textColor: 'text-green-900'
    },
    {
      title: 'Converted',
      value: convertedLeads?.toLocaleString(),
      icon: 'CheckCircle',
      bgColor: 'bg-emerald-50',
      iconColor: 'text-emerald-600',
      textColor: 'text-emerald-900'
    },
    {
      title: 'Total Value',
      value: `$${totalValue?.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
      icon: 'DollarSign',
      bgColor: 'bg-purple-50',
      iconColor: 'text-purple-600',
      textColor: 'text-purple-900'
    },
    {
      title: 'Conversion Rate',
      value: `${conversionRate}%`,
      icon: 'TrendingUp',
      bgColor: 'bg-orange-50',
      iconColor: 'text-orange-600',
      textColor: 'text-orange-900'
    }
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 mb-6">
      {summaryData?.map((item, index) => (
        <div key={index} className={`${item?.bgColor} rounded-lg p-4 border border-gray-200`}>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 mb-1">{item?.title}</p>
              <p className={`text-2xl font-bold ${item?.textColor}`}>{item?.value}</p>
            </div>
            <div className={`p-2 rounded-lg bg-white/50`}>
              <Icon name={item?.icon} size={24} className={item?.iconColor} />
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default LeadSummaryCards;