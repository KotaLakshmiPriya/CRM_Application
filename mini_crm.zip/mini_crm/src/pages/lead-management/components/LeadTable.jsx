import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Button from '../../../components/ui/Button';
import Icon from '../../../components/AppIcon';
import LeadStatusBadge from './LeadStatusBadge';

const LeadTable = ({ leads, onDeleteLead }) => {
  const navigate = useNavigate();
  const [sortField, setSortField] = useState('createdAt');
  const [sortDirection, setSortDirection] = useState('desc');
  const [deleteConfirm, setDeleteConfirm] = useState(null);

  const handleSort = (field) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const sortedLeads = [...leads]?.sort((a, b) => {
    let aValue = a?.[sortField];
    let bValue = b?.[sortField];

    if (sortField === 'createdAt') {
      aValue = new Date(aValue);
      bValue = new Date(bValue);
    } else if (sortField === 'value') {
      aValue = parseFloat(aValue);
      bValue = parseFloat(bValue);
    } else if (typeof aValue === 'string') {
      aValue = aValue?.toLowerCase();
      bValue = bValue?.toLowerCase();
    }

    if (sortDirection === 'asc') {
      return aValue > bValue ? 1 : -1;
    } else {
      return aValue < bValue ? 1 : -1;
    }
  });

  const handleEdit = (leadId) => {
    navigate(`/add-edit-lead?edit=true&id=${leadId}`);
  };

  const handleDelete = (leadId) => {
    setDeleteConfirm(leadId);
  };

  const confirmDelete = () => {
    if (deleteConfirm) {
      onDeleteLead(deleteConfirm);
      setDeleteConfirm(null);
    }
  };

  const handleViewCustomer = (customerId) => {
    navigate(`/customer-details/${customerId}`);
  };

  const getSortIcon = (field) => {
    if (sortField !== field) return 'ArrowUpDown';
    return sortDirection === 'asc' ? 'ArrowUp' : 'ArrowDown';
  };

  if (leads?.length === 0) {
    return (
      <div className="bg-white rounded-lg border border-gray-200 p-12 text-center">
        <Icon name="Target" size={48} className="text-gray-400 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-gray-900 mb-2">No leads found</h3>
        <p className="text-gray-500 mb-6">Get started by creating your first lead or adjust your filters.</p>
        <Button
          variant="default"
          onClick={() => navigate('/add-edit-lead')}
          iconName="Plus"
          iconPosition="left"
        >
          Add Lead
        </Button>
      </div>
    );
  }

  return (
    <>
      <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
        {/* Desktop Table */}
        <div className="hidden md:block overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-6 py-3 text-left">
                  <button
                    onClick={() => handleSort('customerName')}
                    className="flex items-center space-x-1 text-xs font-medium text-gray-500 uppercase tracking-wider hover:text-gray-700"
                  >
                    <span>Customer</span>
                    <Icon name={getSortIcon('customerName')} size={14} />
                  </button>
                </th>
                <th className="px-6 py-3 text-left">
                  <button
                    onClick={() => handleSort('title')}
                    className="flex items-center space-x-1 text-xs font-medium text-gray-500 uppercase tracking-wider hover:text-gray-700"
                  >
                    <span>Lead Title</span>
                    <Icon name={getSortIcon('title')} size={14} />
                  </button>
                </th>
                <th className="px-6 py-3 text-left">
                  <button
                    onClick={() => handleSort('status')}
                    className="flex items-center space-x-1 text-xs font-medium text-gray-500 uppercase tracking-wider hover:text-gray-700"
                  >
                    <span>Status</span>
                    <Icon name={getSortIcon('status')} size={14} />
                  </button>
                </th>
                <th className="px-6 py-3 text-left">
                  <button
                    onClick={() => handleSort('value')}
                    className="flex items-center space-x-1 text-xs font-medium text-gray-500 uppercase tracking-wider hover:text-gray-700"
                  >
                    <span>Value</span>
                    <Icon name={getSortIcon('value')} size={14} />
                  </button>
                </th>
                <th className="px-6 py-3 text-left">
                  <button
                    onClick={() => handleSort('createdAt')}
                    className="flex items-center space-x-1 text-xs font-medium text-gray-500 uppercase tracking-wider hover:text-gray-700"
                  >
                    <span>Created</span>
                    <Icon name={getSortIcon('createdAt')} size={14} />
                  </button>
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {sortedLeads?.map((lead) => (
                <tr key={lead?.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4">
                    <button
                      onClick={() => handleViewCustomer(lead?.customerId)}
                      className="text-sm font-medium text-blue-600 hover:text-blue-800"
                    >
                      {lead?.customerName}
                    </button>
                  </td>
                  <td className="px-6 py-4">
                    <div className="text-sm font-medium text-gray-900">{lead?.title}</div>
                    {lead?.description && (
                      <div className="text-sm text-gray-500 truncate max-w-xs">
                        {lead?.description}
                      </div>
                    )}
                  </td>
                  <td className="px-6 py-4">
                    <LeadStatusBadge status={lead?.status} />
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-900">
                    ${lead?.value?.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-500">
                    {new Date(lead.createdAt)?.toLocaleDateString('en-US')}
                  </td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex items-center justify-end space-x-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleEdit(lead?.id)}
                        iconName="Edit"
                        className="text-gray-600 hover:text-blue-600"
                      />
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDelete(lead?.id)}
                        iconName="Trash2"
                        className="text-gray-600 hover:text-red-600"
                      />
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Mobile Cards */}
        <div className="md:hidden divide-y divide-gray-200">
          {sortedLeads?.map((lead) => (
            <div key={lead?.id} className="p-4">
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <button
                    onClick={() => handleViewCustomer(lead?.customerId)}
                    className="text-sm font-medium text-blue-600 hover:text-blue-800 mb-1"
                  >
                    {lead?.customerName}
                  </button>
                  <h3 className="text-base font-medium text-gray-900 mb-1">{lead?.title}</h3>
                  {lead?.description && (
                    <p className="text-sm text-gray-500 mb-2 line-clamp-2">{lead?.description}</p>
                  )}
                </div>
                <div className="flex items-center space-x-2 ml-4">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleEdit(lead?.id)}
                    iconName="Edit"
                    className="text-gray-600"
                  />
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleDelete(lead?.id)}
                    iconName="Trash2"
                    className="text-gray-600"
                  />
                </div>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <LeadStatusBadge status={lead?.status} />
                  <span className="text-sm font-medium text-gray-900">
                    ${lead?.value?.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </span>
                </div>
                <span className="text-sm text-gray-500">
                  {new Date(lead.createdAt)?.toLocaleDateString('en-US')}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
      {/* Delete Confirmation Modal */}
      {deleteConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-md w-full p-6">
            <div className="flex items-center mb-4">
              <div className="flex-shrink-0 w-10 h-10 bg-red-100 rounded-full flex items-center justify-center">
                <Icon name="AlertTriangle" size={20} className="text-red-600" />
              </div>
              <div className="ml-4">
                <h3 className="text-lg font-medium text-gray-900">Delete Lead</h3>
                <p className="text-sm text-gray-500">Are you sure you want to delete this lead? This action cannot be undone.</p>
              </div>
            </div>
            <div className="flex justify-end space-x-3">
              <Button
                variant="outline"
                onClick={() => setDeleteConfirm(null)}
              >
                Cancel
              </Button>
              <Button
                variant="destructive"
                onClick={confirmDelete}
              >
                Delete
              </Button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default LeadTable;