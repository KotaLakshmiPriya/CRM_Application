import React from 'react';

const LeadStatusBadge = ({ status }) => {
  const getStatusConfig = (status) => {
    switch (status) {
      case 'New':
        return {
          bgColor: 'bg-blue-100',
          textColor: 'text-blue-800',
          dotColor: 'bg-blue-500'
        };
      case 'Contacted':
        return {
          bgColor: 'bg-yellow-100',
          textColor: 'text-yellow-800',
          dotColor: 'bg-yellow-500'
        };
      case 'Converted':
        return {
          bgColor: 'bg-green-100',
          textColor: 'text-green-800',
          dotColor: 'bg-green-500'
        };
      case 'Lost':
        return {
          bgColor: 'bg-red-100',
          textColor: 'text-red-800',
          dotColor: 'bg-red-500'
        };
      default:
        return {
          bgColor: 'bg-gray-100',
          textColor: 'text-gray-800',
          dotColor: 'bg-gray-500'
        };
    }
  };

  const config = getStatusConfig(status);

  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${config?.bgColor} ${config?.textColor}`}>
      <div className={`w-2 h-2 rounded-full mr-1.5 ${config?.dotColor}`}></div>
      {status}
    </span>
  );
};

export default LeadStatusBadge;