import React, { useState, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../../components/ui/Header';
import Breadcrumb from '../../components/ui/Breadcrumb';
import Button from '../../components/ui/Button';
import LeadSummaryCards from './components/LeadSummaryCards';
import LeadFilters from './components/LeadFilters';
import LeadTable from './components/LeadTable';
import LeadPagination from './components/LeadPagination';

const LeadManagement = () => {
  const navigate = useNavigate();
  const [currentUser] = useState({ name: 'John Doe', email: 'john@example.com' });
  
  // Mock leads data
  const [leads] = useState([
    {
      id: 1,
      customerId: 1,
      customerName: "Sarah Johnson",
      title: "Website Redesign Project",
      description: "Complete website overhaul with modern design and improved user experience",
      status: "New",
      value: 15000.00,
      createdAt: "2025-01-05T10:30:00Z"
    },
    {
      id: 2,
      customerId: 2,
      customerName: "Michael Chen",
      title: "E-commerce Platform Development",
      description: "Custom e-commerce solution with payment integration and inventory management",
      status: "Contacted",
      value: 45000.00,
      createdAt: "2025-01-03T14:15:00Z"
    },
    {
      id: 3,
      customerId: 3,
      customerName: "Emily Rodriguez",
      title: "Mobile App Development",
      description: "iOS and Android app for customer engagement and loyalty program",
      status: "Converted",
      value: 32000.00,
      createdAt: "2024-12-28T09:45:00Z"
    },
    {
      id: 4,
      customerId: 4,
      customerName: "David Thompson",
      title: "Digital Marketing Campaign",
      description: "Comprehensive digital marketing strategy including SEO, PPC, and social media",
      status: "Lost",
      value: 8500.00,
      createdAt: "2024-12-25T16:20:00Z"
    },
    {
      id: 5,
      customerId: 5,
      customerName: "Lisa Wang",
      title: "Cloud Migration Services",
      description: "Migration of legacy systems to cloud infrastructure with security enhancements",
      status: "Contacted",
      value: 28000.00,
      createdAt: "2025-01-08T11:00:00Z"
    },
    {
      id: 6,
      customerId: 1,
      customerName: "Sarah Johnson",
      title: "SEO Optimization Package",
      description: "6-month SEO optimization program to improve search rankings",
      status: "New",
      value: 5500.00,
      createdAt: "2025-01-10T13:30:00Z"
    },
    {
      id: 7,
      customerId: 6,
      customerName: "Robert Martinez",
      title: "CRM System Implementation",
      description: "Custom CRM solution with sales pipeline and customer management features",
      status: "Converted",
      value: 22000.00,
      createdAt: "2024-12-20T08:15:00Z"
    },
    {
      id: 8,
      customerId: 7,
      customerName: "Jennifer Kim",
      title: "Brand Identity Design",
      description: "Complete brand identity package including logo, guidelines, and marketing materials",
      status: "New",
      value: 7500.00,
      createdAt: "2025-01-12T15:45:00Z"
    },
    {
      id: 9,
      customerId: 8,
      customerName: "Alex Turner",
      title: "Data Analytics Dashboard",
      description: "Business intelligence dashboard with real-time analytics and reporting",
      status: "Contacted",
      value: 18000.00,
      createdAt: "2025-01-06T12:20:00Z"
    },
    {
      id: 10,
      customerId: 9,
      customerName: "Maria Garcia",
      title: "Social Media Management",
      description: "3-month social media management and content creation package",
      status: "Lost",
      value: 4200.00,
      createdAt: "2024-12-30T10:10:00Z"
    }
  ]);

  // Filter and pagination state
  const [statusFilter, setStatusFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [minValue, setMinValue] = useState('');
  const [maxValue, setMaxValue] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);

  // Filter leads based on current filters
  const filteredLeads = useMemo(() => {
    return leads?.filter(lead => {
      const matchesStatus = statusFilter === 'all' || lead?.status === statusFilter;
      const matchesSearch = searchTerm === '' || 
        lead?.customerName?.toLowerCase()?.includes(searchTerm?.toLowerCase()) ||
        lead?.title?.toLowerCase()?.includes(searchTerm?.toLowerCase());
      const matchesMinValue = minValue === '' || lead?.value >= parseFloat(minValue);
      const matchesMaxValue = maxValue === '' || lead?.value <= parseFloat(maxValue);
      
      return matchesStatus && matchesSearch && matchesMinValue && matchesMaxValue;
    });
  }, [leads, statusFilter, searchTerm, minValue, maxValue]);

  // Pagination calculations
  const totalPages = Math.ceil(filteredLeads?.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const paginatedLeads = filteredLeads?.slice(startIndex, startIndex + itemsPerPage);

  // Reset to first page when filters change
  useEffect(() => {
    setCurrentPage(1);
  }, [statusFilter, searchTerm, minValue, maxValue]);

  const handleClearFilters = () => {
    setStatusFilter('all');
    setSearchTerm('');
    setMinValue('');
    setMaxValue('');
    setCurrentPage(1);
  };

  const handleDeleteLead = (leadId) => {
    // In a real app, this would make an API call
    console.log('Deleting lead:', leadId);
  };

  const handleLogout = () => {
    navigate('/');
  };

  const handlePageChange = (page) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleItemsPerPageChange = (newItemsPerPage) => {
    setItemsPerPage(newItemsPerPage);
    setCurrentPage(1);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header currentUser={currentUser} onLogout={handleLogout} />
      <main className="pt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <Breadcrumb />
          
          {/* Page Header */}
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-8">
            <div>
              <h1 className="text-3xl font-bold text-foreground mb-2">Lead Management</h1>
              <p className="text-muted-foreground">
                Track and manage your sales pipeline with comprehensive lead oversight
              </p>
            </div>
            <div className="mt-4 sm:mt-0">
              <Button
                variant="default"
                onClick={() => navigate('/add-edit-lead')}
                iconName="Plus"
                iconPosition="left"
                className="w-full sm:w-auto"
              >
                Add Lead
              </Button>
            </div>
          </div>

          {/* Summary Cards */}
          <LeadSummaryCards leads={filteredLeads} />

          {/* Filters */}
          <LeadFilters
            statusFilter={statusFilter}
            setStatusFilter={setStatusFilter}
            searchTerm={searchTerm}
            setSearchTerm={setSearchTerm}
            minValue={minValue}
            setMinValue={setMinValue}
            maxValue={maxValue}
            setMaxValue={setMaxValue}
            onClearFilters={handleClearFilters}
          />

          {/* Results Summary */}
          {filteredLeads?.length > 0 && (
            <div className="mb-4">
              <p className="text-sm text-muted-foreground">
                Showing {filteredLeads?.length} of {leads?.length} leads
                {(statusFilter !== 'all' || searchTerm || minValue || maxValue) && (
                  <span className="ml-1">(filtered)</span>
                )}
              </p>
            </div>
          )}

          {/* Lead Table */}
          <LeadTable
            leads={paginatedLeads}
            onDeleteLead={handleDeleteLead}
          />

          {/* Pagination */}
          <LeadPagination
            currentPage={currentPage}
            totalPages={totalPages}
            totalItems={filteredLeads?.length}
            itemsPerPage={itemsPerPage}
            onPageChange={handlePageChange}
            onItemsPerPageChange={handleItemsPerPageChange}
          />
        </div>
      </main>
    </div>
  );
};

export default LeadManagement;