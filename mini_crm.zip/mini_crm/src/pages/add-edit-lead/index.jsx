import React from 'react';
import { useSearchParams } from 'react-router-dom';
import Header from '../../components/ui/Header';
import Breadcrumb from '../../components/ui/Breadcrumb';
import LeadForm from './components/LeadForm';
import StatusIndicator from './components/StatusIndicator';
import Icon from '../../components/AppIcon';

const AddEditLead = () => {
  const [searchParams] = useSearchParams();
  const leadId = searchParams?.get('id');
  const isEditMode = Boolean(leadId);

  // Mock current user data
  const currentUser = {
    id: 1,
    name: 'John Doe',
    email: 'john.doe@company.com',
    role: 'Sales Manager'
  };

  const handleLogout = () => {
    // Handle logout logic
    console.log('User logged out');
  };

  // Custom breadcrumb items
  const breadcrumbItems = [
    { label: 'Dashboard', path: '/dashboard', icon: 'Home' },
    { label: 'Leads', path: '/lead-management', icon: 'Target' },
    { 
      label: isEditMode ? 'Edit Lead' : 'Add Lead', 
      path: '/add-edit-lead', 
      icon: isEditMode ? 'Edit' : 'Plus' 
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header currentUser={currentUser} onLogout={handleLogout} />
      
      <main className="pt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Breadcrumb Navigation */}
          <Breadcrumb customItems={breadcrumbItems} />

          {/* Page Header */}
          <div className="mb-8">
            <div className="flex items-center space-x-3 mb-2">
              <div className="flex items-center justify-center w-10 h-10 bg-primary/10 rounded-lg">
                <Icon name={isEditMode ? 'Edit' : 'Plus'} size={20} color="var(--color-primary)" />
              </div>
              <div>
                <h1 className="text-2xl font-semibold text-foreground">
                  {isEditMode ? 'Edit Lead' : 'Add New Lead'}
                </h1>
                <p className="text-muted-foreground">
                  {isEditMode 
                    ? 'Update lead information and track progress' 
                    : 'Create a new lead and associate it with a customer'
                  }
                </p>
              </div>
            </div>

            {/* Status Legend */}
            <div className="mt-6 p-4 bg-muted/30 rounded-lg border border-border">
              <h3 className="text-sm font-medium text-foreground mb-3">Lead Status Options:</h3>
              <div className="flex flex-wrap gap-3">
                <StatusIndicator status="New" size="sm" />
                <StatusIndicator status="Contacted" size="sm" />
                <StatusIndicator status="Converted" size="sm" />
                <StatusIndicator status="Lost" size="sm" />
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="bg-card rounded-lg border border-border shadow-sm">
            <div className="p-6 border-b border-border">
              <h2 className="text-lg font-medium text-foreground">
                Lead Information
              </h2>
              <p className="text-sm text-muted-foreground mt-1">
                Fill in the details below to {isEditMode ? 'update the' : 'create a new'} lead
              </p>
            </div>

            <div className="p-6">
              <LeadForm />
            </div>
          </div>

          {/* Help Section */}
          <div className="mt-8 bg-primary/5 rounded-lg border border-primary/20 p-6">
            <div className="flex items-start space-x-3">
              <div className="flex items-center justify-center w-8 h-8 bg-primary/10 rounded-full flex-shrink-0">
                <Icon name="Info" size={16} color="var(--color-primary)" />
              </div>
              <div>
                <h3 className="text-sm font-medium text-foreground mb-2">Tips for Lead Management</h3>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• Use descriptive titles to easily identify leads</li>
                  <li>• Associate leads with existing customers for better tracking</li>
                  <li>• Update lead values as negotiations progress</li>
                  <li>• Add detailed notes to track communication history</li>
                  <li>• Change status regularly to reflect current progress</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default AddEditLead;