import React from 'react';
import Icon from '../../../components/AppIcon';

const StatusIndicator = ({ status, size = 'default' }) => {
  const getStatusConfig = (status) => {
    switch (status) {
      case 'New':
        return {
          color: 'var(--color-primary)',
          bgColor: 'bg-primary/10',
          icon: 'Plus',
          label: 'New Lead'
        };
      case 'Contacted':
        return {
          color: 'var(--color-warning)',
          bgColor: 'bg-warning/10',
          icon: 'Phone',
          label: 'Contacted'
        };
      case 'Converted':
        return {
          color: 'var(--color-success)',
          bgColor: 'bg-success/10',
          icon: 'CheckCircle',
          label: 'Converted'
        };
      case 'Lost':
        return {
          color: 'var(--color-error)',
          bgColor: 'bg-error/10',
          icon: 'XCircle',
          label: 'Lost'
        };
      default:
        return {
          color: 'var(--color-muted-foreground)',
          bgColor: 'bg-muted',
          icon: 'Circle',
          label: 'Unknown'
        };
    }
  };

  const config = getStatusConfig(status);
  const iconSize = size === 'sm' ? 14 : size === 'lg' ? 20 : 16;
  const textSize = size === 'sm' ? 'text-xs' : size === 'lg' ? 'text-base' : 'text-sm';
  const padding = size === 'sm' ? 'px-2 py-1' : size === 'lg' ? 'px-4 py-2' : 'px-3 py-1.5';

  return (
    <div className={`inline-flex items-center space-x-2 ${padding} ${config?.bgColor} rounded-full`}>
      <Icon name={config?.icon} size={iconSize} color={config?.color} />
      <span className={`font-medium ${textSize}`} style={{ color: config?.color }}>
        {config?.label}
      </span>
    </div>
  );
};

export default StatusIndicator;