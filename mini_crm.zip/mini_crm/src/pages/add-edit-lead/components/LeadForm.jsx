import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import Icon from '../../../components/AppIcon';

const LeadForm = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const leadId = searchParams?.get('id');
  const isEditMode = Boolean(leadId);

  const [formData, setFormData] = useState({
    title: '',
    customerId: '',
    value: '',
    status: 'New',
    notes: ''
  });

  const [errors, setErrors] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Mock customers data
  const customers = [
    { value: '1', label: 'John Smith - john.smith@email.com' },
    { value: '2', label: 'Sarah Johnson - sarah.johnson@email.com' },
    { value: '3', label: 'Michael Brown - michael.brown@email.com' },
    { value: '4', label: 'Emily Davis - emily.davis@email.com' },
    { value: '5', label: 'David Wilson - david.wilson@email.com' },
    { value: '6', label: 'Lisa Anderson - lisa.anderson@email.com' },
    { value: '7', label: 'Robert Taylor - robert.taylor@email.com' },
    { value: '8', label: 'Jennifer Martinez - jennifer.martinez@email.com' }
  ];

  const statusOptions = [
    { value: 'New', label: 'New' },
    { value: 'Contacted', label: 'Contacted' },
    { value: 'Converted', label: 'Converted' },
    { value: 'Lost', label: 'Lost' }
  ];

  // Mock lead data for edit mode
  const mockLeadData = {
    id: leadId,
    title: 'Enterprise Software Solution',
    customerId: '2',
    value: '25000',
    status: 'Contacted',
    notes: 'Initial discussion completed. Customer is interested in our enterprise package. Follow-up scheduled for next week to discuss pricing and implementation timeline.'
  };

  useEffect(() => {
    if (isEditMode) {
      setIsLoading(true);
      // Simulate API call
      setTimeout(() => {
        setFormData(mockLeadData);
        setIsLoading(false);
      }, 800);
    }
  }, [isEditMode, leadId]);

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));

    // Clear error when user starts typing
    if (errors?.[field]) {
      setErrors(prev => ({
        ...prev,
        [field]: ''
      }));
    }
  };

  const handleValueChange = (e) => {
    const value = e?.target?.value?.replace(/[^0-9.]/g, '');
    handleInputChange('value', value);
  };

  const formatCurrency = (value) => {
    if (!value) return '';
    const numericValue = parseFloat(value);
    if (isNaN(numericValue)) return value;
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 2
    })?.format(numericValue);
  };

  const validateForm = () => {
    const newErrors = {};

    if (!formData?.title?.trim()) {
      newErrors.title = 'Lead title is required';
    }

    if (!formData?.customerId) {
      newErrors.customerId = 'Please select a customer';
    }

    if (!formData?.value || parseFloat(formData?.value) <= 0) {
      newErrors.value = 'Please enter a valid lead value';
    }

    if (!formData?.status) {
      newErrors.status = 'Please select a status';
    }

    setErrors(newErrors);
    return Object.keys(newErrors)?.length === 0;
  };

  const handleSubmit = async (e) => {
    e?.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    setIsSubmitting(true);

    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Success - redirect to lead management
      navigate('/lead-management', { 
        state: { 
          message: `Lead ${isEditMode ? 'updated' : 'created'} successfully!`,
          type: 'success'
        }
      });
    } catch (error) {
      setErrors({ submit: 'Failed to save lead. Please try again.' });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCancel = () => {
    navigate(-1);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="flex items-center space-x-3">
          <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary"></div>
          <span className="text-muted-foreground">Loading lead data...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto">
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Lead Title */}
        <Input
          label="Lead Title"
          type="text"
          placeholder="Enter lead title"
          value={formData?.title}
          onChange={(e) => handleInputChange('title', e?.target?.value)}
          error={errors?.title}
          required
          className="mb-4"
        />

        {/* Customer Selection */}
        <Select
          label="Customer"
          placeholder="Select a customer"
          options={customers}
          value={formData?.customerId}
          onChange={(value) => handleInputChange('customerId', value)}
          error={errors?.customerId}
          required
          searchable
          className="mb-4"
        />

        {/* Lead Value */}
        <div className="mb-4">
          <Input
            label="Lead Value (USD)"
            type="text"
            placeholder="0.00"
            value={formData?.value}
            onChange={handleValueChange}
            error={errors?.value}
            required
            className="mb-2"
          />
          {formData?.value && (
            <p className="text-sm text-muted-foreground mt-1">
              Formatted: {formatCurrency(formData?.value)}
            </p>
          )}
        </div>

        {/* Status Selection */}
        <Select
          label="Status"
          placeholder="Select status"
          options={statusOptions}
          value={formData?.status}
          onChange={(value) => handleInputChange('status', value)}
          error={errors?.status}
          required
          className="mb-4"
        />

        {/* Notes */}
        <div className="mb-6">
          <label className="block text-sm font-medium text-foreground mb-2">
            Notes
          </label>
          <textarea
            placeholder="Add notes about this lead..."
            value={formData?.notes}
            onChange={(e) => handleInputChange('notes', e?.target?.value)}
            rows={4}
            className="w-full px-3 py-2 border border-border rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent resize-none text-sm"
          />
        </div>

        {/* Submit Error */}
        {errors?.submit && (
          <div className="flex items-center space-x-2 p-3 bg-error/10 border border-error/20 rounded-md">
            <Icon name="AlertCircle" size={16} color="var(--color-error)" />
            <span className="text-sm text-error">{errors?.submit}</span>
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex items-center justify-end space-x-3 pt-6 border-t border-border">
          <Button
            type="button"
            variant="outline"
            onClick={handleCancel}
            disabled={isSubmitting}
          >
            Cancel
          </Button>
          <Button
            type="submit"
            loading={isSubmitting}
            iconName="Save"
            iconPosition="left"
          >
            {isEditMode ? 'Update Lead' : 'Save Lead'}
          </Button>
        </div>
      </form>
    </div>
  );
};

export default LeadForm;