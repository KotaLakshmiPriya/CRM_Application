import React from 'react';
import { useNavigate } from 'react-router-dom';
import Button from '../../../components/ui/Button';

const QuickActions = () => {
  const navigate = useNavigate();

  const actions = [
    {
      title: 'Add New Customer',
      description: 'Create a new customer profile',
      icon: 'UserPlus',
      variant: 'default',
      onClick: () => navigate('/add-edit-customer')
    },
    {
      title: 'Create Lead',
      description: 'Add a new sales opportunity',
      icon: 'Target',
      variant: 'outline',
      onClick: () => navigate('/add-edit-lead')
    },
    {
      title: 'View All Customers',
      description: 'Browse customer directory',
      icon: 'Users',
      variant: 'ghost',
      onClick: () => navigate('/customer-list')
    },
    {
      title: 'Manage Leads',
      description: 'Track sales pipeline',
      icon: 'BarChart3',
      variant: 'ghost',
      onClick: () => navigate('/lead-management')
    }
  ];

  return (
    <div className="bg-card border border-border rounded-lg p-6">
      <h3 className="text-lg font-semibold text-foreground mb-4">Quick Actions</h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {actions?.map((action, index) => (
          <div key={index} className="p-4 border border-border rounded-lg hover:bg-muted/50 transition-colors duration-150">
            <Button
              variant={action?.variant}
              iconName={action?.icon}
              iconPosition="left"
              onClick={action?.onClick}
              className="w-full justify-start mb-2"
            >
              {action?.title}
            </Button>
            <p className="text-xs text-muted-foreground">{action?.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default QuickActions;