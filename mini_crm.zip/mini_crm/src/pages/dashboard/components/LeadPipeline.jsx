import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const LeadPipeline = ({ leads }) => {
  const [selectedStatus, setSelectedStatus] = useState('all');

  const statusConfig = {
    new: { label: 'New', color: 'bg-primary', textColor: 'text-primary' },
    contacted: { label: 'Contacted', color: 'bg-warning', textColor: 'text-warning' },
    qualified: { label: 'Qualified', color: 'bg-accent', textColor: 'text-accent' },
    converted: { label: 'Converted', color: 'bg-success', textColor: 'text-success' },
    lost: { label: 'Lost', color: 'bg-error', textColor: 'text-error' }
  };

  const getLeadsByStatus = (status) => {
    if (status === 'all') return leads;
    return leads?.filter(lead => lead?.status === status);
  };

  const filteredLeads = getLeadsByStatus(selectedStatus);

  const getStatusCount = (status) => {
    return leads?.filter(lead => lead?.status === status)?.length;
  };

  return (
    <div className="bg-card border border-border rounded-lg p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-foreground">Lead Pipeline</h3>
        <div className="flex items-center space-x-2">
          <Button
            variant={selectedStatus === 'all' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setSelectedStatus('all')}
          >
            All ({leads?.length})
          </Button>
          {Object.entries(statusConfig)?.map(([status, config]) => (
            <Button
              key={status}
              variant={selectedStatus === status ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setSelectedStatus(status)}
            >
              {config?.label} ({getStatusCount(status)})
            </Button>
          ))}
        </div>
      </div>
      <div className="space-y-3 max-h-80 overflow-y-auto">
        {filteredLeads?.map((lead) => (
          <div key={lead?.id} className="flex items-center justify-between p-3 border border-border rounded-lg hover:bg-muted/50 transition-colors duration-150">
            <div className="flex items-center space-x-3">
              <div className={`w-3 h-3 rounded-full ${statusConfig?.[lead?.status]?.color || 'bg-muted'}`}></div>
              <div>
                <p className="text-sm font-medium text-foreground">{lead?.title}</p>
                <p className="text-xs text-muted-foreground">{lead?.company}</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm font-medium text-foreground">${lead?.value?.toLocaleString()}</span>
              <span className={`text-xs px-2 py-1 rounded-full ${statusConfig?.[lead?.status]?.color || 'bg-muted'} text-white`}>
                {statusConfig?.[lead?.status]?.label || lead?.status}
              </span>
            </div>
          </div>
        ))}
        {filteredLeads?.length === 0 && (
          <div className="text-center py-8">
            <Icon name="Target" size={48} className="mx-auto text-muted-foreground mb-2" />
            <p className="text-muted-foreground">No leads found for selected status</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default LeadPipeline;