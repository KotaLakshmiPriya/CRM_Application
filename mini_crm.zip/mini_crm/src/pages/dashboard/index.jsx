import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../../components/ui/Header';
import Breadcrumb from '../../components/ui/Breadcrumb';
import MetricCard from './components/MetricCard';
import ChartCard from './components/ChartCard';
import ActivityFeed from './components/ActivityFeed';
import QuickActions from './components/QuickActions';
import LeadPipeline from './components/LeadPipeline';

const Dashboard = () => {
  const navigate = useNavigate();
  const [currentUser, setCurrentUser] = useState(null);

  // Mock user data
  useEffect(() => {
    const mockUser = {
      id: 1,
      name: "John Smith",
      email: "john.smith@company.com",
      role: "Sales Manager"
    };
    setCurrentUser(mockUser);
  }, []);

  // Mock metrics data
  const metricsData = [
    {
      title: "Total Customers",
      value: "1,247",
      change: "+12.5%",
      changeType: "positive",
      icon: "Users",
      color: "primary"
    },
    {
      title: "Active Leads",
      value: "89",
      change: "+8.2%",
      changeType: "positive",
      icon: "Target",
      color: "warning"
    },
    {
      title: "Conversion Rate",
      value: "24.8%",
      change: "+2.1%",
      changeType: "positive",
      icon: "TrendingUp",
      color: "success"
    },
    {
      title: "Monthly Revenue",
      value: "$127,450",
      change: "-3.2%",
      changeType: "negative",
      icon: "DollarSign",
      color: "error"
    }
  ];

  // Mock chart data
  const monthlyPerformanceData = [
    { name: 'Jan', value: 45000 },
    { name: 'Feb', value: 52000 },
    { name: 'Mar', value: 48000 },
    { name: 'Apr', value: 61000 },
    { name: 'May', value: 55000 },
    { name: 'Jun', value: 67000 },
    { name: 'Jul', value: 72000 },
    { name: 'Aug', value: 69000 },
    { name: 'Sep', value: 78000 }
  ];

  const leadStatusData = [
    { name: 'New', value: 25 },
    { name: 'Contacted', value: 32 },
    { name: 'Qualified', value: 18 },
    { name: 'Converted', value: 14 },
    { name: 'Lost', value: 11 }
  ];

  // Mock activity data
  const recentActivities = [
    {
      id: 1,
      type: 'customer_added',
      title: 'New customer added',
      description: 'Sarah Johnson from TechCorp was added to the system',
      timestamp: new Date(Date.now() - 300000) // 5 minutes ago
    },
    {
      id: 2,
      type: 'lead_converted',
      title: 'Lead converted',
      description: 'Microsoft deal worth $45,000 has been converted',
      timestamp: new Date(Date.now() - 900000) // 15 minutes ago
    },
    {
      id: 3,
      type: 'lead_created',
      title: 'New lead created',
      description: 'Enterprise software opportunity for GlobalTech',
      timestamp: new Date(Date.now() - 1800000) // 30 minutes ago
    },
    {
      id: 4,
      type: 'customer_updated',
      title: 'Customer profile updated',
      description: 'Contact information updated for Acme Industries',
      timestamp: new Date(Date.now() - 3600000) // 1 hour ago
    },
    {
      id: 5,
      type: 'lead_lost',
      title: 'Lead marked as lost',
      description: 'StartupXYZ deal did not proceed due to budget constraints',
      timestamp: new Date(Date.now() - 7200000) // 2 hours ago
    }
  ];

  // Mock leads data for pipeline
  const mockLeads = [
    {
      id: 1,
      title: 'Enterprise Software License',
      company: 'TechCorp Solutions',
      value: 75000,
      status: 'new'
    },
    {
      id: 2,
      title: 'Cloud Migration Project',
      company: 'GlobalTech Inc',
      value: 125000,
      status: 'contacted'
    },
    {
      id: 3,
      title: 'CRM Implementation',
      company: 'StartupXYZ',
      value: 45000,
      status: 'qualified'
    },
    {
      id: 4,
      title: 'Security Audit Services',
      company: 'SecureBank',
      value: 32000,
      status: 'converted'
    },
    {
      id: 5,
      title: 'Website Redesign',
      company: 'DesignStudio',
      value: 18000,
      status: 'lost'
    },
    {
      id: 6,
      title: 'Mobile App Development',
      company: 'InnovateNow',
      value: 95000,
      status: 'contacted'
    }
  ];

  const handleLogout = () => {
    setCurrentUser(null);
    navigate('/');
  };

  return (
    <div className="min-h-screen bg-background">
      <Header currentUser={currentUser} onLogout={handleLogout} />
      <main className="pt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <Breadcrumb />
          
          {/* Welcome Section */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-foreground mb-2">
              Welcome back, {currentUser?.name || 'User'}!
            </h1>
            <p className="text-muted-foreground">
              Here's what's happening with your CRM today.
            </p>
          </div>

          {/* Metrics Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {metricsData?.map((metric, index) => (
              <MetricCard
                key={index}
                title={metric?.title}
                value={metric?.value}
                change={metric?.change}
                changeType={metric?.changeType}
                icon={metric?.icon}
                color={metric?.color}
              />
            ))}
          </div>

          {/* Charts Section */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            <ChartCard
              title="Monthly Performance"
              type="bar"
              data={monthlyPerformanceData}
              height={300}
            />
            <ChartCard
              title="Lead Status Distribution"
              type="pie"
              data={leadStatusData}
              height={300}
            />
          </div>

          {/* Activity and Actions Section */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            <ActivityFeed activities={recentActivities} />
            <QuickActions />
          </div>

          {/* Lead Pipeline */}
          <div className="mb-8">
            <LeadPipeline leads={mockLeads} />
          </div>
        </div>
      </main>
    </div>
  );
};

export default Dashboard;