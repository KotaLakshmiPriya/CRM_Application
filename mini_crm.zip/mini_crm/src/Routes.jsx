import React from "react";
import { BrowserRouter, Routes as RouterRoutes, Route } from "react-router-dom";
import ScrollToTop from "components/ScrollToTop";
import ErrorBoundary from "components/ErrorBoundary";
import NotFound from "pages/NotFound";
import AddEditCustomer from './pages/add-edit-customer';
import CustomerList from './pages/customer-list';
import AddEditLead from './pages/add-edit-lead';
import Dashboard from './pages/dashboard';
import CustomerDetails from './pages/customer-details';
import LeadManagement from './pages/lead-management';

// Auth pages
import Login from './pages/auth/Login';
import Register from './pages/auth/Register';

const Routes = () => {
  return (
    <BrowserRouter>
      <ErrorBoundary>
      <ScrollToTop />
      <RouterRoutes>
        {/* Auth routes */}
        <Route path="/auth/login" element={<Login />} />
        <Route path="/auth/register" element={<Register />} />
        
        {/* CRM routes - accessible in development mode */}
        <Route path="/" element={<Dashboard />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/add-edit-customer" element={<AddEditCustomer />} />
        <Route path="/customer-list" element={<CustomerList />} />
        <Route path="/add-edit-lead" element={<AddEditLead />} />
        <Route path="/customer-details" element={<CustomerDetails />} />
        <Route path="/lead-management" element={<LeadManagement />} />
        <Route path="*" element={<NotFound />} />
      </RouterRoutes>
      </ErrorBoundary>
    </BrowserRouter>
  );
};

export default Routes;