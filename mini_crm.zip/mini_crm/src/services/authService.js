import { supabase } from '../lib/supabase';

export const authService = {
  // Sign in with email and password
  async signIn(email, password) {
    try {
      const { data, error } = await supabase?.auth?.signInWithPassword({
        email,
        password
      })
      
      if (error) {
        return { data: null, error: error?.message };
      }
      
      return { data, error: null }
    } catch (error) {
      if (error?.message?.includes('Failed to fetch') || 
          error?.message?.includes('AuthRetryableFetchError')) {
        return { 
          data: null, 
          error: 'Cannot connect to authentication service. Your Supabase project may be paused or inactive. Please check your Supabase dashboard.' 
        }
      }
      return { data: null, error: 'Authentication failed. Please try again.' }
    }
  },

  // Sign up with email, password and additional user data
  async signUp(email, password, userData = {}) {
    try {
      const { data, error } = await supabase?.auth?.signUp({
        email,
        password,
        options: {
          data: {
            full_name: userData?.full_name || '',
            role: userData?.role || 'member'
          }
        }
      })
      
      if (error) {
        return { data: null, error: error?.message };
      }
      
      return { data, error: null }
    } catch (error) {
      if (error?.message?.includes('Failed to fetch')) {
        return { 
          data: null, 
          error: 'Cannot connect to authentication service. Please check your network connection.' 
        }
      }
      return { data: null, error: 'Registration failed. Please try again.' }
    }
  },

  // Sign out current user
  async signOut() {
    try {
      const { error } = await supabase?.auth?.signOut()
      if (error) {
        return { error: error?.message };
      }
      return { error: null }
    } catch (error) {
      return { error: 'Sign out failed. Please try again.' }
    }
  },

  // Get current session
  async getSession() {
    try {
      const { data: { session }, error } = await supabase?.auth?.getSession()
      if (error) {
        return { session: null, error: error?.message };
      }
      return { session, error: null }
    } catch (error) {
      return { session: null, error: 'Failed to get session.' }
    }
  },

  // Get current user
  async getUser() {
    try {
      const { data: { user }, error } = await supabase?.auth?.getUser()
      if (error) {
        return { user: null, error: error?.message };
      }
      return { user, error: null }
    } catch (error) {
      return { user: null, error: 'Failed to get user.' }
    }
  },

  // Get user profile from user_profiles table
  async getUserProfile(userId) {
    try {
      const { data, error } = await supabase?.from('user_profiles')?.select('*')?.eq('id', userId)?.single()
      
      if (error) {
        return { profile: null, error: error?.message };
      }
      
      return { profile: data, error: null }
    } catch (error) {
      return { profile: null, error: 'Failed to get user profile.' }
    }
  }
}